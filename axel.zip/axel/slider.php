                <!-- Filtre prix -->
                <div class="">
                    <p class="aside-title">Filtrer par prix</p>
                    <div class="slidecontainer">
                        <input type="range" min="1" max="500" value="50" class="slider" id="myRange">
                        <p>Prix max. <span id="price-value"></span> €</p>
                    </div>
                </div>
                <!-- /Filtre prix -->